// ===== Lấy các phần tử HTML theo id =====
const arena = document.getElementById('arena');           // khu vực chơi
const scoreEl = document.getElementById('score');         // ô hiển thị điểm
const timeEl = document.getElementById('time');           // ô hiển thị thời gian
const startBtn = document.getElementById('start');        // nút Bắt đầu
const colorBtn = document.getElementById('color-btn');    // nút Đổi màu nền
const playerBtn = document.getElementById('player-btn');  // nút Người chơi
const playerInfo = document.getElementById('player-info');// chỗ hiện mã sinh viên
const timeSelect = document.getElementById('time-select');// ô chọn thời gian
const overlay = document.getElementById('overlay');       // lớp phủ khi chưa chơi/hết giờ
const overTitle = document.getElementById('over-title');  // dòng chữ trên lớp phủ
const overScore = document.getElementById('over-score');  // số điểm tổng trên lớp phủ

// ===== Biến lưu trạng thái trò chơi =====
const SIZE = 44;         // kích thước mục tiêu (px)
const MOVE_MS = 1000;    // mục tiêu tự đổi chỗ sau mỗi 1000ms = 1 giây
let score = 0;           // điểm hiện tại
let timeLeft = 30;       // thời gian còn lại (giây)
let running = false;     // true = đang chơi, false = đã dừng/khoá
let target = null;       // mục tiêu (hình tròn đỏ)
let countdownId = null;  // lưu bộ đếm ngược để dừng sau này
let moveId = null;       // lưu bộ đổi vị trí để dừng sau này

// ===== Đặt mục tiêu vào vị trí ngẫu nhiên trong #arena =====
function moveTarget() {
  if (!target) {                                // nếu chưa có mục tiêu thì tạo mới
    target = document.createElement('div');     // tạo thẻ div
    target.className = 'target';                // gán class để có kiểu hình tròn
    target.addEventListener('click', hitTarget);// khi click vào mục tiêu thì gọi hitTarget
    arena.appendChild(target);                  // đưa mục tiêu vào #arena
  }
  // random trong khoảng 0 -> (rộng arena - kích thước mục tiêu) để không tràn ra ngoài
  target.style.left = Math.floor(Math.random() * (arena.clientWidth - SIZE)) + 'px';
  target.style.top = Math.floor(Math.random() * (arena.clientHeight - SIZE)) + 'px';
}

// ===== Click trúng mục tiêu =====
function hitTarget() {
  if (!running) return;                         // game đã khoá thì không làm gì
  score++;                                      // tăng điểm lên 1
  scoreEl.textContent = score;                  // cập nhật điểm trên màn hình
  moveTarget();                                 // đổi vị trí mục tiêu ngay lập tức
  clearInterval(moveId);                        // huỷ bộ đếm 1 giây cũ
  moveId = setInterval(moveTarget, MOVE_MS);    // đếm lại 1 giây từ đầu
}

// ===== Bắt đầu trò chơi =====
function startGame() {
  score = 0;                                    // đặt lại điểm về 0
  timeLeft = Number(timeSelect.value);          // lấy thời gian người chơi đã chọn
  running = true;                               // cho phép chơi
  scoreEl.textContent = score;                  // hiện điểm 0
  timeEl.textContent = timeLeft;                // hiện thời gian đã chọn
  overlay.classList.add('hide');                // ẩn lớp phủ
  startBtn.disabled = true;                     // khoá nút Bắt đầu khi đang chơi
  timeSelect.disabled = true;                   // khoá ô chọn thời gian khi đang chơi
  moveTarget();                                 // sinh mục tiêu đầu tiên
  moveId = setInterval(moveTarget, MOVE_MS);    // cứ 1 giây đổi vị trí một lần
  countdownId = setInterval(() => {             // cứ 1 giây chạy đoạn lệnh dưới
    timeLeft--;                                 // giảm thời gian 1 giây
    timeEl.textContent = timeLeft;              // cập nhật đồng hồ
    if (timeLeft <= 0) endGame();               // về 0 thì kết thúc game
  }, 1000);
}

// ===== Kết thúc trò chơi =====
function endGame() {
  running = false;                              // khoá thao tác chơi
  clearInterval(countdownId);                   // dừng đếm ngược
  clearInterval(moveId);                        // dừng đổi vị trí mục tiêu
  if (target) { target.remove(); target = null; }// xoá mục tiêu khỏi màn hình
  overTitle.textContent = 'Hết giờ! Tổng điểm của bạn:'; // dòng thông báo
  overScore.textContent = score;                // hiện tổng điểm
  overlay.classList.remove('hide');             // hiện lớp phủ (che kín arena)
  startBtn.disabled = false;                    // mở lại nút Bắt đầu
  startBtn.textContent = 'Chơi lại';            // đổi chữ nút thành Chơi lại
  timeSelect.disabled = false;                  // mở lại ô chọn thời gian
}

// ===== Nút Đổi màu nền: màu ngẫu nhiên =====
colorBtn.addEventListener('click', () => {
  const hue = Math.floor(Math.random() * 360);  // chọn ngẫu nhiên sắc độ 0-359
  arena.style.background = 'hsl(' + hue + ', 60%, 30%)'; // đặt màu nền (tối vừa phải)
});

// ===== Nút Người chơi: hiện mã sinh viên =====
playerBtn.addEventListener('click', () => {
  playerInfo.textContent = 'Mã sinh viên: 241A010520'; // hiện mã SV
});

// ===== Chọn thời gian: cập nhật đồng hồ ngay khi đổi =====
timeSelect.addEventListener('change', () => {
  timeEl.textContent = timeSelect.value;        // hiện thời gian vừa chọn
});

// ===== Nút Bắt đầu =====
startBtn.addEventListener('click', startGame);  // bấm nút thì chạy startGame
